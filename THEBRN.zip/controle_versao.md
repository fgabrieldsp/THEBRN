# controle_versao.md

Linha do tempo e controle de versões do projeto THEBRN

---

## Histórico
- 2025-06-04: Início do controle de versão do projeto.
- 2025-06-04: Extração dos domínios do espinhadorsal.md para arquivos ES6.
- 2025-06-04: Criação dos arquivos financeiro.js e logistica.js como entidades próprias, conforme estrutura modular do sistema.
